
	// var apiKey = '92a09bdcf1de6c9639ded05007276241-us21';
	// var audienceId ='d14fca0422';
	

const mailchimp = require("@mailchimp/mailchimp_marketing");
const express = require('express');
const bodyParser = require('body-parser');
const https = require("https");
const md5 = require("md5");
var port = process.env.PORT  || 3000;

const app = express();
app.use(bodyParser.urlencoded({extended:true}));
app.use(express.static('public'));



app.get('/',function(req,res){
	// res.send("app is running");
	res.sendFile(__dirname+"/signup.html");
});

mailchimp.setConfig({
  apiKey: "92a09bdcf1de6c9639ded05007276241-us21",
  server: "us21",
});


// async function run() {
//   // const response = await mailchimp.ping.get();

//   // const response = await mailchimp.lists.getAllLists();
//   const response = await mailchimp.lists.getList("d14fca0422");
//   // const response = await mailchimp.lists.getListMember();
//   console.log(response);
// }

// run();
app.post('/',function(req,res){
	const firstName = req.body.firstName;
	const lastName = req.body.lastName;
	const email = req.body.email;
	const list_id = "d14fca0422";
	
	var subscriberHash = md5(email.toLowerCase());
	const addmembers = async () => {
		try{
			const response = await mailchimp.lists.addListMember(list_id, {
		email_address: email,
		status: "subscribed",
		merge_fields:{
			FNAME: firstName,
			LNAME: lastName
			}
			
			});
		}catch(e){
			 console.log("The email is subscribed");
		}

	  }

	 addmembers();

 const check = async () => {
	 try {
	 const response1 = await mailchimp.lists.getListMember(
	 list_id,
	 subscriberHash
	 );
	 if(response1.status == 'subscribed'){
		 // res.send("The email is subscribed successful");
		 res.sendFile(__dirname+'/success.html');
	 };
	 } catch(e){
		  // res.send("Please try another e-mail");
		  res.sendFile(__dirname+'/failure.html');
	 }
	 
 };
check();
});

// app.get('/failure',function(req,res){
// 	res.sendFile(__dirname+'/signup.html');
// })

app.post('/failure',function(req,res){
	res.redirect('/');
});

// app.get('/success',function(req,res){
// 	res.sendFile(__dirname+'/signup.html');
// })

// app.post('/success',function(req,res){
// 	res.redirect('/');
// });







app.listen( port,function(){
	console.log("Server is running on port 3000");
});






